var sbmptn_current_time, sbmptn_deadline_time;
sbmptn_current_time = new Date();
sbmptn_deadline_time = '23 Jun 2022 15:00:00 +0700';
